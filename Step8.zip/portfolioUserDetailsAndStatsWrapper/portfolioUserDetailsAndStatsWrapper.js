import { LightningElement } from 'lwc';

export default class PortfolioUserDetailsAndStatsWrapper extends LightningElement {
    recordId="a015g00000nfoqYAAQ"
    objectApiName="Portfolio__c"
}